-- ============================================================================
--  PROYECTO: tanquepid  (Control PID de bomba sobre tanque IoT ESP32)
--  Base de datos y tablas. Se puede re-ejecutar sin perder usuarios.
-- ============================================================================

CREATE DATABASE IF NOT EXISTS tanquepid
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE tanquepid;

-- ---------------------------------------------------------------------------
-- Usuarios (login / roles). NO borrar en la limpieza de registros.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS usuarios (
    id        INT AUTO_INCREMENT PRIMARY KEY,
    username  VARCHAR(50)  NOT NULL UNIQUE,
    password  VARCHAR(100) NOT NULL,
    rol       VARCHAR(20)  NOT NULL DEFAULT 'operador'  -- admin / operador / invitado
);

-- Usuarios de ejemplo (solo se insertan si no existen).
INSERT INTO usuarios (username, password, rol) VALUES
    ('admin',    'admin123', 'admin'),
    ('operador', 'op123',    'operador'),
    ('invitado', 'guest',    'invitado')
ON DUPLICATE KEY UPDATE username = username;

-- ---------------------------------------------------------------------------
-- Mediciones del tanque.
-- Se añaden salida_pid (% PWM aplicado a la bomba) y setpoint (cm objetivo).
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS mediciones_tanque (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    fecha         DATETIME   NOT NULL DEFAULT CURRENT_TIMESTAMP,
    nivel_cm      FLOAT      NULL,
    lectura_ultra FLOAT      NULL,          -- lectura cruda del ultrasonido
    hay_flujo     TINYINT(1) NOT NULL DEFAULT 0,
    estado_bomba  TINYINT(1) NOT NULL DEFAULT 0,
    salida_pid    FLOAT      NULL,          -- salida del PID 0-100 % (PWM de la bomba)
    setpoint      FLOAT      NULL           -- nivel objetivo (cm) activo en ese instante
);

-- Si ya tienes una tabla mediciones_tanque de la versión por histéresis,
-- en lugar de recrearla añade solo las dos columnas nuevas:
-- ALTER TABLE mediciones_tanque ADD COLUMN salida_pid FLOAT NULL AFTER estado_bomba;
-- ALTER TABLE mediciones_tanque ADD COLUMN setpoint   FLOAT NULL AFTER salida_pid;

-- ---------------------------------------------------------------------------
-- Auditoría de acciones de usuario (login, control, cambios de PID, etc.).
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS auditoria_usuarios (
    id      INT AUTO_INCREMENT PRIMARY KEY,
    fecha   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    usuario VARCHAR(50)  NULL,
    accion  VARCHAR(255) NULL
);
