 cd C:\Program Files\MySQL\MySQL Server 8.4\bin
 "mysql.exe" -u root -p  
CREATE DATABASE IF NOT EXISTS proyecto_tanque;
USE proyecto_tanque;

-- Elimina la base de datos si ya existe y la crea de nuevo
DROP DATABASE IF EXISTS tanquepid_db;
CREATE DATABASE tanquepid_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Selecciona la base de datos
USE tanquepid_db;

-- Ejemplo de creación de tabla: Usuarios
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Ejemplo de creación de tabla: Tanques (ajusta según tu app)
CREATE TABLE tanques (
    id INT AUTO_INCREMENT PRIMARY KEY,
    codigo VARCHAR(50) NOT NULL,
    capacidad_litros DECIMAL(10, 2),
    estado VARCHAR(50) DEFAULT 'Activo'
);

-- Insertar registros iniciales de prueba
INSERT INTO usuarios (nombre, email, password) VALUES 
('Administrador', 'admin@tanquepid.com', '123456'),
('Usuario Pruebas', 'test@tanquepid.com', '123456');

INSERT INTO tanques (codigo, capacidad_litros, estado) VALUES 
('TNQ-001', 5000.00, 'Activo'),
('TNQ-002', 10000.00, 'Mantenimiento');